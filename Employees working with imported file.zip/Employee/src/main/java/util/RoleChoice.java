package util;

public enum RoleChoice {
	ADMIN, MANAGER, EMPLOYEE
}
