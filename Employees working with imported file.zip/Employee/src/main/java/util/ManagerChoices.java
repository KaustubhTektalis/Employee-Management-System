package util;

public enum ManagerChoices {
	UPDATE, CHANGE_PASSWORD,SELF_DETAILS,SHOW_ALL, EXIT
}