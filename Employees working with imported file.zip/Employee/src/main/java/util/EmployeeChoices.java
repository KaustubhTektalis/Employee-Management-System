package util;

public enum EmployeeChoices {
	SHOW_SELF, UPDATE, CHANGE_PASSWORD, EXIT
}