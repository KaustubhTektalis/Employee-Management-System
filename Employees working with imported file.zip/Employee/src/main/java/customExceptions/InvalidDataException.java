package customExceptions;

public class InvalidDataException extends Exception {
	public InvalidDataException(String s) {
		super(s);
	}
}
