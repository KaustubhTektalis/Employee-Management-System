package customExceptions;

public class EmployeeNotFoundException extends Exception {

	public EmployeeNotFoundException(String s) {
		super(s);
	}
}
