package customExceptions;

public class IdFormatWrongException extends Exception {
	public IdFormatWrongException(String s) {
		super(s);
	}
}
